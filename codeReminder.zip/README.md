## Code Reminder

This extension just have a simple yet very useful feature, it fetches 'potd' from various DSA problem solving websites
This extension fetches problem of the day from LeetCode, Geeks for Geeks and Coding Ninjas


### What does it do? and why it's helpful?

* You don't have to visit all websites one at a time to solve the POTD s
* You get all at the same place with just an click
* One click will take you direct to the problem solving page
* One click on the extension to remind you thay you might solve these today

### Screenshot || DEMO







https://user-images.githubusercontent.com/68517592/187304807-e063917b-4aeb-49ae-a488-82ada7cdcfea.mp4








### Installation

* I will publish the extension on chrome webstore soon, working on a few more features
